export const SelectionParameters = {
  selectedItems: 4,
  isIntercalated: false,
  showTipoPago: true
};

export const TipoDePagos = [
  { value: 1, name: 'Minimo' },
  { value: 2, name: 'Otro Monto' },
  { value: 3, name: 'Total' }
];
