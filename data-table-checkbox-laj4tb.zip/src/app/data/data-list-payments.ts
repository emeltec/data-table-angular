export const DataListPayment = [
  {
    companyName: 'DP World Depósito mes 1',
    codeClient: '201010101013',
    numberDocument: 'R12333',
    expiration: '22/03/2021',
    extraPayment: '-',
    fixedCharge: '-',
    amount: 'S/ 820.00'
  },
  {
    companyName: 'DP World Depósito mes 2',
    codeClient: '201010101013',
    numberDocument: 'R10000',
    expiration: '22/03/2021',
    extraPayment: '-',
    fixedCharge: '-',
    amount: 'S/ 1,000.00'
  },
  {
    companyName: 'DP World Depósito mes 3',
    codeClient: '201010101013',
    numberDocument: 'R10000',
    expiration: '22/03/2021',
    extraPayment: '-',
    fixedCharge: '-',
    amount: 'S/ 1,000.00'
  },
  {
    companyName: 'DP World Depósito mes 4',
    codeClient: '201010101013',
    numberDocument: 'R10000',
    expiration: '22/03/2021',
    extraPayment: '-',
    fixedCharge: '-',
    amount: 'S/ 1,000.00'
  },
  {
    companyName: 'DP World Depósito mes 5',
    codeClient: '201010101013',
    numberDocument: 'R10000',
    expiration: '22/03/2021',
    extraPayment: '-',
    fixedCharge: '-',
    amount: 'S/ 1,000.00'
  }
];
