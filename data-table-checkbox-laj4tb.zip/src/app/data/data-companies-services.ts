export const companiesApi = [
  {
    companyId: '015',
    companyName: 'DP World'
  },
  {
    companyId: '001',
    companyName: 'Universidad Quinteros'
  },
  {
    companyId: '006',
    companyName: 'Sedapal'
  },
  {
    companyId: '008',
    companyName: 'Entel'
  },
  {
    companyId: '010',
    companyName: 'Club privado'
  }
]

export const servicesApi = [
  {
    serviceId: '011223',
    serviceName: 'Desestiba (por contenedor)',
    companyId: '015'
  },
  {
    serviceId: '011224',
    serviceName: 'Depósito temporal',
    companyId: '015'
  },
  {
    serviceId: '011225',
    serviceName: 'Descarga',
    companyId: '015'
  },
  {
    serviceId: '01015',
    serviceName: 'Matriculas',
    companyId: '001'
  },
  {
    serviceId: '022055',
    serviceName: 'Pensión',
    companyId: '001'
  },
  {
    serviceId: '075413',
    serviceName: 'Consumo de agua',
    companyId: '006'
  },
  {
    serviceId: '061032',
    serviceName: 'Costo de reconexión',
    companyId: '006'
  },
  {
    serviceId: '051032',
    serviceName: 'Convenio de servicio',
    companyId: '006'
  },
  {
    serviceId: '0604023',
    serviceName: 'Entel empresas',
    companyId: '008'
  },
  {
    serviceId: '0604555',
    serviceName: 'Entel postpago',
    companyId: '008'
  },
  {
    serviceId: '0604512',
    serviceName: 'Suscripción mensual',
    companyId: '010'
  }
]