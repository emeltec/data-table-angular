import { Component, Input, OnInit } from '@angular/core';
import {
  TipoDePagos,
  SelectionParameters
} from './config/selection-parameters';
import { TableDebtsColumns } from './config/table-debts-columns';
import { DataListPayment } from './data/data-list-payment';

@Component({
  selector: 'data-table-component',
  templateUrl: './data-table-component.html',
  styleUrls: ['./data-table-component.scss']
})
export class DataTableComponent implements OnInit {
  public checkAll: boolean;
  @Input() debtsList: any[];
  public selectionParameters: any;
  public tipoDePagos: any;
  constructor() {
    this.selectionParameters = SelectionParameters;
    this.checkAll = false;
    this.tipoDePagos = TipoDePagos;
  }

  ngOnInit() {}

  selectedItem(item: any, index: number) {
    item.isChecked = !item.isChecked;
    const countChecked = this.debtsList.filter(_ => _.isChecked).length;
    if (this.selectionParameters.isIntercalated) {
      if (countChecked === this.selectionParameters.selectedItems)
        this.debtsList.forEach(_i => !_i.isChecked && (_i.isDisabled = true));
      else this.debtsList.map(_i => _i.isDisabled && (_i.isDisabled = false));
    } else {
      this.debtsList.forEach((_i, _x) => {
        if (_x > index) {
          _i.isChecked = false;
          _i.isDisabled = true;
        }
      });
      if (countChecked < this.selectionParameters.selectedItems)
        this.debtsList[index + 1].isDisabled = !item.isChecked;
    }
  }

  selectedAll(): void {
    this.checkAll = !this.checkAll;
    this.debtsList.forEach((_item, _index) => {
      if (_index < this.selectionParameters.selectedItems) {
        _item.isChecked = this.checkAll;
        !this.selectionParameters.isIntercalated &&
          (_item.isDisabled = !this.checkAll);
      } else {
        this.selectionParameters.isIntercalated &&
          (_item.isDisabled = this.checkAll);
      }
    });
    !this.checkAll && (this.debtsList[0].isDisabled = false);
    console.log(this.checkAll);
  }

  changeAmount(event: any, item: any): void {
    const minAmount = parseFloat(item.minimo.replace('S/ ', ''));
    const maxAmount = item.total.replace('S/ ', '').replace(',', '');
    const actuallyAmount = parseFloat(event.detail);

    console.log(item.total);
    console.log(
      `monto ingresado : ${minAmount}, montoMinimo : ${minAmount}, montoMax : ${maxAmount}`
    );
    if (actuallyAmount < minAmount || actuallyAmount > maxAmount) {
      item.stateErr = 'error';
      item.textErr = 'Monto invalido';
    } else {
      item.stateErr = '';
      item.textErr = '';
    }
    item.amount = `S/ ${actuallyAmount}`;
  }

  changeSelectTipoPago(value: any, item: any): void {
    item.showInput = false;
    switch (value.detail) {
      case '1':
        item.amount = `${item.minimo}`;
        break;
      case '2':
        item.showInput = true;
        break;
      case '3':
        item.amount = `${item.total}`;
        break;
      default:
        break;
    }
  }
}
